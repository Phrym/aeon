@extends('layout.main')

@section('body')
<h2>The Aeon Project</h2>
<small>version 2.0.0-*</small>

@stop