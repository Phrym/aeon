@extends('layout.admain')

@section('body')


{{ Form::open(array('url' => 'admin/room', 'class' => 'form-signin')) }}
    @if($errors->all())
    <div class="alert alert-warning">
    @foreach($errors->all() as $error)
      <p>{{ $error }}</p>
    @endforeach
    </div>
    @endif
        <label for="firstname" >First Name: </label>
        {{ Form::text('firstname', Input::old('firstname'), array('placeholder' => 'First Name', 'class' => 'form-control')) }}
        
        <label for="middlename" >Middle Name: </label>
        {{ Form::text('middlename', Input::old('middlename') , array('placeholder' => 'Middle Name', 'class' => 'form-control')) }}
        <label for="lastname"> Last Name: </label>
        {{ Form::text('lastname', Input::old('lastname'), array('placeholder' => 'Last Name', 'class' => 'form-control')) }}
        <br />
        {{ Form::submit('Create', array('class' => 'btn btn-lg btn-primary btn-block')) }}
        <div>
        </div>
{{ Form::close() }}
@stop