@extends('layout.admain')

@section('extra-css')
@stop

@section('body')
  <h2>Scheduling for {{ $schedules->code." - ".$schedules->year." ".$schedules->section }}
      <small>[<a href="{{ URL::to('admin/schedule/verify?courses='.$schedules->id) }}">back to schedule table</a>]</small></h2>
  <hr />
  {{ Form::open() }}
    <? // get all course, faculty, and room related to this object ?>
    <div class="col-md-12">
      <p>Shift: {{ ucfirst( $schedules->shift ) }}</p>
      <div class="row">
        <div class="col-md-2">
          <label for="faculty">Instructor: </label>
        </div>
        <div class="col-md-7">
          <select class="form-control" name="faculty_id">
          <option>Select Instructor...</option>
          @foreach($faculty as $f)
           <?php $staff = Staff::find($f->staff_id) ?>
           <option value="{{ $f->id }}">{{ $staff->first_name." ".$staff->middle_name." ".$staff->last_name }}</option>
          @endforeach
          </select>    
        </div>  
      </div>
      <div class="row">
        <div class="col-md-2">
          <label for="prospectus_id">Subject: </label>
        </div>
        <div class="col-md-7">
         {{ Form::select('prospectus_id', $subject, '',['class' => 'form-control']) }}
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">
          <label for="room_id">Room: </label>
        </div>
        <div class="col-md-7">
         {{ Form::select('room_id', $room, '',['class' => 'form-control']) }}
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">
          <label for="day_id">Day: </label>    
        </div>
        <div class="col-md-7">
          {{ Form::select('day_id', $day, '',['class' => 'form-control']) }}    
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
        <h3 align="center"><b>Please Follow 24 Hours Time Mode, Otherwise the Table will never display the schedule correctly.</b></h3>          
        </div>
      </div>
      <div class="row">
        <div class="col-md-2">
        <label for="time_in">Time In:</label>
        </div>
        <div class="col-md-10">
          <div class="col-md-3">
            {{ Form::text('time_in_hour', Input::old('time_in_hour'), ['class' => 'form-control', 'placeholder' => 'Hours (HH)']) }}
          </div>
          <div class="col-md-1">
            <b>:</b>
          </div>
          <div class="col-md-3">
            {{ Form::text('time_in_minute', Input::old('time_in_minute'), ['class' => 'form-control', 'placeholder' => 'Minutes (MM)']) }}
          </div>    
        </div>
      </div>    
      <div class="row">
        <div class="col-md-2">
          <label for="time_out">Time Out:</label>    
        </div>
        <div class="col-md-10">
          <div class="col-md-3">
            {{ Form::text('time_out_hour', Input::old('time_out_hour'), ['class' => 'form-control', 'placeholder' => 'Hours (HH)']) }}
          </div>
          <div class="col-md-1">
            <b>:</b>
          </div>
          <div class="col-md-3">
            {{ Form::text('time_out_minute', Input::old('time_out_minute'), ['class' => 'form-control', 'placeholder' => 'Minutes (MM)']) }}
          </div>
        </div>
      </div>    
    {{ Form::submit('Submit', ['class' => ' btn btn-success']) }}
    </div>
    
  {{ Form::close() }}
@stop

@section('extra-js')

@stop