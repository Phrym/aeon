@extends('layout.scheduler')

@section('extra-css')
    <link href="{{ URL::asset('assets/css/aeon.css') }}" rel="stylesheet">
@stop

@section('body')
<center>
  <div class="row">
   <div class="col-md-4">
     
   </div>
   <div class="col-md-4">
    <h2>Creating Schedule for {{ $curriculum }}</h2>
   </div>
   <div class="col-md-4">
      <a href="{{ URL::to('admin/schedule/verified/'.$curriculum) }}" class="btn btn-material-teal">Add Schedule Element</a>
   </div>   
  </div>
  <div ng-controller="AeonScheduleWidget" class="AeonScheduleWidgetStyleBasic">
  	<div class="col-md-2">
    <table width="100%">
      <thead>
        <th>Time Start / Time End</th>
      </thead>
      <tbody>
          @foreach($scheduleBundle as $time)
          <tr class="AeonSideBarHeader">
            <td><div class="AeonScheduleTableTimeElement">{{ $time['time_start'] .' - '. $time['time_end'] }}</div></td>
          </tr>
          @endforeach
      </tbody> 
    </table>      
    </div>
      <div class="col-md-10">
       @foreach($days as $day)
        <?php $rowpos = 0 ?>
        <div class="col-md-1">
          <th>{{ $day->day }}</th>
          @foreach($schedules as $s)
            @if($s->day_id == $day->id)
              <div class="row" style="margin-top:{{ ($rowpos == 0 ? ($s->time_in - $time_start) : ($s->time_in - $rowpos) - 41 ) }}px;height:{{ ($s->time_out - $s->time_in) + 41 }}px;background:#00e0e0">
                <small><p>{{ $s->faculty()->get()->first()->staff()->get()->first()->last_name.", ".$s->faculty()->get()->first()->staff()->get()->first()->first_name }}</p></small>
                <small><p>{{ $s->room()->get()->first()->code }}</p></small>
                <small><p>{{ Prospectus::find($s->prospectus_id)->code }}</p></small>
              </div>
              <?php $rowpos = $s->time_out ?>
            @endif
          @endforeach
        </div>
       @endforeach
      </div>
    </div>
</center>

@stop

@section('extra-js')

@stop 