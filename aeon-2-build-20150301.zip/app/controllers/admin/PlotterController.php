<?php

use \Aeon\Library\Chronos\Repository\ChronosRepositoryInterface as Chronosphere;
use \Aeon\Aeon;

class PlotterController extends Admin
{
	protected $app;

	protected $storage;

	protected $transformer;

	protected $data;

	protected $facultyContainer;

	protected $config;

	public function __construct(Aeon $app, Chronosphere $chronos, \Faculty $f)
	{
		parent::__construct();
		$this->app = $app;
		$this->storage = $chronos;
		$this->data = $this->app->setApplicationSetting();
		$this->facultyContainer = $f;
		$this->data['days'] = Day::orderBy('count')->get();
		$this->data['courses'] = [null => 'Make Schedule For...'] + 
													\Bachelor::where('isOffered', '=', true)->select(DB::raw('concat(concat(code, "-",year), " ",section) as curriculum, id'))
															->groupBy('curriculum')
															->lists('curriculum','id');
	}

 	public function getIndex()
 	{
 		return Response::make( View::make('admin.schedule_index', $this->data) , 200);
 	}

 	public function getVerify()
 	{
 		$chronos = new \Aeon\Library\Chronos\Chronos;
 		$this->data['curriculum'] 		= Bachelor::find(Input::get('courses'));
 		$this->data['scheduleBundle'] 	= $chronos->getTimeSettings();
 		$this->data['time_start'] 		= $chronos->getTimeStart();
 		$this->data['time_end'] 		= $chronos->getTimeEnd();
 		$this->data['schedules'] 		= $this->storage->findByBachelorId(Input::get('courses'));

 		return Response::make( View::make('admin.scheduler', $this->data), 200);
 	}

 	public function getVerified($id)
 	{ 	
 		$this->data['day'] 			= \Day::orderBy('count')->lists('day','id');
 		$this->data['subject'] 		= [null => 'Select Subject...'] + \Prospectus::where('bachelor_id', '=', $id)->lists('description','id');
 		$this->data['room'] 		= [null => 'Select Room...'] + \Room::lists('description', 'id');
 		$this->data['faculty'] 		= $this->facultyContainer->all(); 
 		$this->data['schedules'] 	= \Bachelor::find($id);
 		return Response::make(View::make('admin.schedule_make',$this->data), 200);
 	}

 	public function postVerified($id)
 	{
 		$notCreated = $this->storage->createOrUpdate(Input::all(), $id);
 		return $notCreated;

 		if($notCreated == false)
 		{
 			return Redirect::to('admin/schedule/verified/'.$id)->with('error_message','Conflict Alert');	
 		}
 		elseif($notCreated)
 		{
			return Redirect::to('admin/schedule/verified'.$id)->withErrors($notCreated);
 		}
 		return Redirect::to('admin/schedule/verified/'.$id)->with('success_message','Your Schedule was Updated!');
 	}

 	public function postClear()
 	{
 		// only owner can access
 		// drop timeplot table
 	}

}
