<?php

class UpdateController extends \Admin
{
	// only owner/developer has the ability to update the system
	// it can also be customized to make administrator be authorized to update
	// the system
}