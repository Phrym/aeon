<?php

use Aeon\Aeon;
use \Aeon\Library\Chronos\Repository\ChronosRepositoryInterface as Chronosphere;

class PagesController extends BaseController {

	protected $data = array();

	protected $storage;

	public function __construct(Aeon $app, Chronosphere $chronosphere)
	{
		$this->data = $app->setApplicationSetting();
		$this->storage = $chronosphere;
		//$this->beforeFilter('checkInstallation');
		$this->beforeFilter('csrf', array('on'=>'post'));
	}

	public function getIndex()
	{
		if(Auth::check()) return Redirect::to('admin');
		return Response::make( View::make('index', $this->data) );
	}

	public function getAbout()
	{
	//	Auth::user()->authorizeUser('admin');
		return View::make('about', $this->data);
	}

	public function getHelp()
	{	
		return View::make('about',$this->data);
	}

	public function postLogin()
	{
		$val = Validator::make(Input::all(), [
				'username'   => 'required|min:5',
				'password'   => 'required|alphaNum|min:5',
			]);

		if($val->fails())
		{
			return Redirect::to('index')
				->withErrors($val) 
				->withInput(Input::except('password')); 
		} 
		else 
		{
			$userdata = array(
				'username' 	=> Input::get('username'),
				'password' 	=> Input::get('password')
			);

			if (Auth::attempt($userdata)) 
			{
				return Redirect::intended('admin')->with('success_message', 'Welcome '.  Auth::user()->username. ' !');
			} 
			else 
			{	 	
				return Redirect::to('index')->with('error_message', 'Invalid Login Credential, Please Try Again.');
			}
		}
	}

	public function getSchedule($id)
	{
		$chronos = new \Aeon\Library\Chronos\Chronos;
		$this->data['days'] = Day::orderBy('count')->get();
 		$this->data['curriculum'] = Input::get('courses');
 		$this->data['scheduleBundle'] = $chronos->getTimeSettings();
 		$this->data['time_start'] = $chronos->getTimeStart();
 		$this->data['schedules'] = $this->storage->findByBachelorId($id);
 //		$this->data['instructor'] = [null => 'Instructors'] + \Faculty::with('Staff')->select(DB::raw('concat(last_name, ", ",first_name) as fullname, id'))->lists('fullname','id');
 //		$this->data['subject'] = [null => 'Subjects'] + \Prospectus::lists('code','id');
 //		$this->data['room'] = [null => 'Rooms'] + \Room::lists('code','id');

		return Response::make( View::make('schedule', $this->data), 200);
	}

	public function getLogout()
	{
		Auth::logout();
		return Redirect::to('index')->with('success_message', 'Logged Out Successfully!');
	}
}
