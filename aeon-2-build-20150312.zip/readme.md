Aeon Project 2.0.0 Final
--------------------------------------

This is the Final and End of Support for this Project. I decided to discontinue this project due to the lack of time, and support. IF ever there's a person who'll find this system interesting and willing to continue the existing work, Please feel free and safe to modify the existing work BUT never forget to give a proper credit to the original discoverer or developer. I am hoping to see people who'll continue this job. Thanks.

Introduction
--------------------------------------
Aeon Project (aeon schedule management system) former Clockwork Scheduling System is a free open sourced (also a failure) Schedule Management System made primarily for Cebu Technological University of Tuburan, this system aims to help and provide ease to schedulers who uses the old and complex method of scheduling and also students who are eagerly waiting for the schedule to come.

Changelogs:

version 2.0.0-final
	- Implemented delete_ Authorization Role
version 2.0.0-test#4
	- Pagodabox Initial Support (incomplete)
	- Conflict Checker
	- Pagination
	- PDF Converter added
	- Installation Wizard (incomplete)
version 2.0.0-test#3
	- Faster Schedule Table Display
	- OAuth2 Implementation (incomplete)
	- Elevated Authorization Added (incomplete)
	- uses Material Design
	- switched to Laravel 4.2
version 1.2.1
	- (bug) slow querying
	- made using customized Model Controller View Design Pattern


To do:
	- Account Settings
	- Updater
	- Installer
	- Table in PDF
	- Units Display (done)
	- Implementation of all Roles
	- Typographic Errors
	- OAuth2

Future Plan:
	- base schedules on timestamps in order to separate old schedules from new.
	- AJAX implementation
	- chat server
	- notifications


Info:

/app/src/Aeon 						- Contains the codes made by me.
/app/src/Aeon/Library/Chronos/ 		- Contains the codes responsible for Scheduling and Time Value
/app/src/Aeon/Library/Chameleon.php - Theming (-started only 1%)
/app/src/Repository/ 				- Contains the Files that acts as a storage
/app/src/Transformer/				- Contains the Files that transforms the data given by our Repo

