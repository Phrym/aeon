<?php

return [
	'title' => 'Default',
	'version' => '1.0.0',
	'description' => 'Default Aeon Theme',
	'author' => [
		[
			'name' => 'Jacob Baring',
			'email' => 'electro7bug@gmail.com'
		]
	]
	'website' => ''
];